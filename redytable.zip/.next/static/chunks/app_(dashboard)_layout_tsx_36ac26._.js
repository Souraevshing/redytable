(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/app_(dashboard)_layout_tsx_36ac26._.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/app_(dashboard)_layout_tsx_36ac26._.js",
  "chunks": [
    "static/chunks/app_ef461e._.css",
    "static/chunks/app_(dashboard)_layout_tsx_c978a2._.js"
  ],
  "source": "dynamic"
});
