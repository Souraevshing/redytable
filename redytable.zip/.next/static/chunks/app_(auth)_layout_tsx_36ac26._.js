(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/app_(auth)_layout_tsx_36ac26._.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/app_(auth)_layout_tsx_36ac26._.js",
  "chunks": [
    "static/chunks/app_2416d5._.css",
    "static/chunks/_511a5f._.js"
  ],
  "source": "dynamic"
});
