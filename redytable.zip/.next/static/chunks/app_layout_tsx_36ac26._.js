(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/app_layout_tsx_36ac26._.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/app_layout_tsx_36ac26._.js",
  "chunks": [
    "static/chunks/app_d0d911._.css",
    "static/chunks/app_layout_tsx_83fc40._.js"
  ],
  "source": "dynamic"
});
