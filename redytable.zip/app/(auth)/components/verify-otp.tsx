export const VerifyOTP = () => {
  return <div>Verify otp</div>;
};

export default VerifyOTP;
